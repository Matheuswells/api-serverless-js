
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'grizzy',
  applicationName: 'api-serverless-js',
  appUid: 'Y8jMctRXMXdWNP33mT',
  orgUid: 'f545ef6a-7dd0-4834-8229-06b915a09fd5',
  deploymentUid: '103a753c-e48e-4cfa-a723-8d4aa132cdd8',
  serviceName: 'api-serverless-js',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'api-serverless-js-dev-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}